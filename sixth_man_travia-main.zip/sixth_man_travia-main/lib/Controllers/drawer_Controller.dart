// // drawer_Controller.dart
// import 'package:get/get.dart';

// class DrawerControllerX extends GetxController {
//   var isDrawerOpen = false.obs;

//   void openDrawer() {
//     isDrawerOpen.value = true;
//   }

//   void closeDrawer() {
//     isDrawerOpen.value = false;
//   }

//   void toggleDrawer() {
//     isDrawerOpen.value = !isDrawerOpen.value;
//   }
// }
