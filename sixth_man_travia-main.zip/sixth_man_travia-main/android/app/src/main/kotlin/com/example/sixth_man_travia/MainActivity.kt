package com.example.sixth_man_travia

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
