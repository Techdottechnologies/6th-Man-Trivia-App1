-3 Categories of 10 questions for all 30 teams
	-Tracks your best score, fastest time, attempts, and overall team score
-Daily Crossword
	-Archive each crossword in the app for potential to play again
	-10 words - 10 points for every correct answer
	-    -5  points for every incorrect word
	-     -10 points if you submit without filling out whole crossword
	-       +25 Points if you complete whole puzzle without mistakes
	-Time Incentives for points

Time to Complete
Bonus Points
≤ 2:30
+50 pts
2:31 – 4:00
+40 pts
4:01 – 6:00
+25 pts
6:01 – 8:00
+10 pts
> 8:00 or incomplete
+0 pts


-Be able to share scores for team and crossword with friends
-friends and global leader board for both
-Show a streak of days playing the crossword in a row
-Choosing their favorite team 
-How scoring works (brief popup) 
-Prompting to "Play Daily Crossword" first
Payments
-$4.99 Remove ads forever
-$3.99 Unlock all archived crosswords
-$0.99 unlock last week of archived crosswords
-$6.99 Unlock all archived crosswords+Remove ads forever



Flutter 0,0

